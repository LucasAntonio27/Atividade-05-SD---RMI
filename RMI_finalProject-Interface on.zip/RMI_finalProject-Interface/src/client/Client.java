//UNIFESSPA - Universidade do Sul e Sudeste do Pará
//Alunos: Cristina Vitoria Leal Leite, Lucas Antonio da Silva Lima e Lucas Leite de Oliveira
package client;
//Imposts para uso no programa
import java.io.BufferedOutputStream;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import server.Interface;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class Client {
    
    static String caminhoClient = "src/arquivosDoCliente/";
    static String caminhoServer = "src/arquivosDoServidor/";
    /**
     *
     */
    public Registry registry;

    /**
     *
     */
    static public Interface carregar;
    static public Registros classe;
    static{                                                                     //Tornando static todos os componentes de registro para utilizar nos métodos staticos 
        Registry registry = null;
        try {
            registry = LocateRegistry.getRegistry("localhost", 1234); //Registrando o cliente no RMI
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            carregar = (Interface) registry.lookup("Carregar");             //Pegando da rede de nomes a interface cadastrada
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Registros classe = new Registros();                                     
            registry.bind("Notificar", classe);                                      //Registrando um serviço que vai ser utiliZADO pelo servidor para notificar o client
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    /**
     *
     * @param args
     * @throws Exception
     * @throws IOException
     */

    static void notificacao(String msg) {                                       //Método de notificação que é chamado por algum serviço
        JOptionPane.showMessageDialog(null,msg);
        //System.out.println(notifica);
    }

    static public void upload(String selecionado) throws FileNotFoundException, IOException{                                
        caminhoClient = caminhoClient + selecionado;                 //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
        File arquivoSelecionado = new File(caminhoClient);                  //Criando variavel do tipo File com o caminho criado anteriormente
        byte[] arquivoEnviar = new byte[(int) arquivoSelecionado.length()]; //Criando um vetor de bytes que vai receber o seu tamanho baseado no tamanho do arquivo.
        FileInputStream fl = new FileInputStream(arquivoSelecionado);       //Criando um novo buffer de entrada para colocar o arquivo a ser enviado nele    
        fl.read(arquivoEnviar, 0, arquivoEnviar.length);                    //Escrevendo no buffer o arquivo e seu tamanho
        System.out.println("Enviando...");                        //
        carregar.upLoadFile(arquivoEnviar, selecionado);                    //Chamando o serviço remoto que fará o upload
        fl.close();                                                         //fechando buffer
    }
    static public void download(String selecionado) throws FileNotFoundException, IOException{
        caminhoClient = caminhoClient + selecionado;              //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
        //File arquivoSelecionado = new File(caminhoServer);                  //Criando variavel do tipo File com o caminho criado anteriormente
        byte[] arquivoRecebido = carregar.downLoadFile(selecionado);       //Chamando o serviço de download e guardando os bytes do arquivo na variavel "arquivoRecebido"
        System.out.println("Baixando...");                                  //
        File arquivo = new File(caminhoClient);                             //Criando nova variavel do tipo file
        BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(arquivo));//Criando um buffer de saida
        output.write(arquivoRecebido);                                      //Escrevendo arquivo recebido 
        output.flush();                                                     //Forçando escrita
        output.close();                                                     //Fechando buffer de saida
    }
    static public String[] verRegistros() throws RemoteException{
        String[] inter = carregar.getInteressesString();                        //Chama o serviço que retorna todos os registros de interesses
        return inter;
    }
    static public void registrar(String registro) throws RemoteException{
        carregar.Registry(registro, classe, 10000, 1);                          //Chama o serviço de registro de interesse e cadastra o interesse
    }
    static public void cancelarRegistro(String registro) throws RemoteException{
        carregar.Registry(registro, classe, 10000, 2);                          //Recebe o interesse a ser removido da lista de interesses e chama o serviço    
    }
    static public String[][] arquivosServer() throws RemoteException{
        String[][] Infos = carregar.listFiles(caminhoServer);                   //Retorna uma matriz com todas as informações 
        return Infos;
    }
}