//UNIFESSPA - Universidade do Sul e Sudeste do Pará
//Alunos: Cristina Vitoria Leal Leite, Lucas Antonio da Silva Lima e Lucas Leite de Oliveira
package client;
//Imposts para uso no programa
import java.io.BufferedOutputStream;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import server.Interface;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import static java.lang.Integer.parseInt;
import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class Client {
    
    static String caminhoClient = "src/arquivosDoCliente/";
    static String caminhoServer = "src/arquivosDoServidor/";
    /**
     *
     */
    public Registry registry;

    /**
     *
     */
    static public Interface carregar;
    static public Registros classe;
    static{
        Registry registry = null;
        //Registros classe;
        
        try {
            registry = LocateRegistry.getRegistry("localhost", 1234); //Registrando o cliente no RMI
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            carregar = (Interface) registry.lookup("Carregar");             //Pegando da rede de nomes a interface cadastrada
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Registros classe = new Registros();
            registry.bind("Notificar", classe);
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    /**
     *
     * @param args
     * @throws Exception
     * @throws IOException
     */

    static void notificacao(String msg) {                                       //Método de notificação que é chamado por algum serviço
        JOptionPane.showMessageDialog(null,msg);
        //System.out.println(notifica);
    }

    static public void upload(String selecionado) throws FileNotFoundException, IOException{                                
        caminhoClient = caminhoClient + selecionado;                 //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
        File arquivoSelecionado = new File(caminhoClient);                  //Criando variavel do tipo File com o caminho criado anteriormente
        byte[] arquivoEnviar = new byte[(int) arquivoSelecionado.length()]; //Criando um vetor de bytes que vai receber o seu tamanho baseado no tamanho do arquivo.
        FileInputStream fl = new FileInputStream(arquivoSelecionado);       //Criando um novo buffer de entrada para colocar o arquivo a ser enviado nele    
        fl.read(arquivoEnviar, 0, arquivoEnviar.length);                    //Escrevendo no buffer o arquivo e seu tamanho
        System.out.println("Enviando...");                        //
        carregar.upLoadFile(arquivoEnviar, selecionado);                    //Chamando o serviço remoto que fará o upload
        fl.close();                                                         //fechando buffer
    }
    static public void download(String selecionado) throws FileNotFoundException, IOException{
        caminhoClient = caminhoClient + selecionado;              //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
        //File arquivoSelecionado = new File(caminhoServer);                  //Criando variavel do tipo File com o caminho criado anteriormente
        byte[] arquivoRecebido = carregar.downLoadFile(selecionado);       //Chamando o serviço de download e guardando os bytes do arquivo na variavel "arquivoRecebido"
        System.out.println("Baixando...");                                  //
        File arquivo = new File(caminhoClient);                             //Criando nova variavel do tipo file
        BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(arquivo));//Criando um buffer de saida
        output.write(arquivoRecebido);                                      //Escrevendo arquivo recebido 
        output.flush();                                                     //Forçando escrita
        output.close();                                                     //Fechando buffer de saida
    }
    static public String[] verRegistros() throws RemoteException{
        String[] inter = carregar.getInteressesString();
        return inter;
    }
    static public void registrar(String registro) throws RemoteException{
                                                                                      //Recebe o nome do arquivo de interesse 
        carregar.Registry(registro, classe, 10000, 1);                               //Chama o serviço de registro de interesse e cadastra o interesse
    }
    static public void cancelarRegistro(String registro) throws RemoteException{
        carregar.Registry(registro, classe, 10000, 2);                          //Recebe o interesse a ser removido da lista de interesses e chama o serviço
        
    }
    static public String[][] arquivosServer() throws RemoteException{
        String[][] Infos = carregar.listFiles(caminhoServer);
        return Infos;
    }
}
/*switch (teclado) {

                    case "1" -> {
                        System.out.println("Digite o nome do arquivo para envio:");         //
                        selecionado = in.readLine();                                 //Recebendo do teclado e guardando em "selecionado"
                        caminhoClient = caminhoClient + selecionado;                 //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
                        File arquivoSelecionado = new File(caminhoClient);                  //Criando variavel do tipo File com o caminho criado anteriormente
                        byte[] arquivoEnviar = new byte[(int) arquivoSelecionado.length()]; //Criando um vetor de bytes que vai receber o seu tamanho baseado no tamanho do arquivo.
                        FileInputStream fl = new FileInputStream(arquivoSelecionado);       //Criando um novo buffer de entrada para colocar o arquivo a ser enviado nele    
                        fl.read(arquivoEnviar, 0, arquivoEnviar.length);                    //Escrevendo no buffer o arquivo e seu tamanho
                        System.out.println("Upload in progress...");                        //
                        carregar.upLoadFile(arquivoEnviar, selecionado);                    //Chamando o serviço remoto que fará o upload
                        fl.close();                                                         //fechando buffer
                    }

                    case "2" -> {
                        System.out.println("Digite o nome do arquivo para baixar:");        //
                        selecionado = in.readLine();                                 //Recebendo do teclado e guardando em "selecionado"
                        caminhoClient = caminhoClient + selecionado;              //Concatenando o caminho da pasta do cliente com o nome do arquivo a ser enviado, para criar o caminho até o arquivo
                        //File arquivoSelecionado = new File(caminhoServer);                  //Criando variavel do tipo File com o caminho criado anteriormente
                        byte[] arquivoRecebido = carregar.downLoadFile(selecionado);       //Chamando o serviço de download e guardando os bytes do arquivo na variavel "arquivoRecebido"
                        System.out.println("Baixando...");                                  //
                        File arquivo = new File(caminhoClient);                             //Criando nova variavel do tipo file
                        BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(arquivo));//Criando um buffer de saida
                        output.write(arquivoRecebido);                                      //Escrevendo arquivo recebido 
                        output.flush();                                                     //Forçando escrita
                        output.close();                                                     //Fechando buffer de saida
                    }

                    case "3" -> {

                        System.out.println("////Arquivos disponíveis no servidor atualmente////");      //
                        String caminho[][] = carregar.listFiles(caminhoServer);                         //Chamando o serviço que lista todas as informações dos arquivos da pasta
                        
                        for (int i = 0; i < caminho.length; i++) {                                      //Laço de repetição para imprimir dados                                      
                            System.out.println(caminho[i][0] + " - " + caminho[i][1] + " - " + caminho[i][2]);
                        }

                        System.out.println("////FIM////");                                              //
                        
                        while (selecionado2 < 2) {                                                    //Laço de repetição para selecionar opções de registrar interesse
                            System.out.println("Para registrar interesse em arquivo não disponível digite 0, 1 para cancelar registro e 2 para sair");
                            selecionado2 = Integer.parseInt(in.readLine());                                                //Recebendo opção selecionada
                            if (0 == selecionado2) {                                              //Se for opção zero
                                System.out.println("\nSeus interesses:\n");                             //
                                String[] inter = carregar.getInteressesString();                        //Solicitação de serviço que exibi todos os interesses registrados
                                for (String inter1 : inter) {                                           //Laço de repetição para imprimir os registros          
                                    System.out.println(inter1);                                         //
                                }
                                
                                System.out.println("Digite o nome do arquivo que deseja registrar interesse: ");
                                String arq = in.readLine();                                             //Recebe o nome do arquivo de interesse 
                                carregar.Registry(arq, classe, 10000, 1);                               //Chama o serviço de registro de interesse e cadastra o interesse

                            } else if (1 == selecionado2) {                                       // Se for selecionado 1, ele imprime os interesses
                                System.out.println("\nSeus interesses:\n");                             //
                                String[] inter = carregar.getInteressesString();                        //
                                for (String inter1 : inter) {                                           //
                                    System.out.println(inter1);                                         //
                                }
                                
                                System.out.println("\nDigite o nome do Interesse que deseja remover:\n");
                                String arq = in.readLine();                                             //Recebe o interesse a ser removido da lista de interesses
                                carregar.Registry(arq, classe, 10000, 2);                               //Chama serviço de registro para remover o resgistro de interesse selecionado
                                

                            }
                        }
                    }

                    default -> {                                                                        //Caso padrão para qualquer outra opção
                        System.out.println("Opcao inexistente!");
                    }

                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }*/
